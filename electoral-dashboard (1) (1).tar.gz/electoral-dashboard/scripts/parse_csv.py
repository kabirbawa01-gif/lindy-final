import csv
import json
from io import StringIO

# Get the CSV content from the attachment
csv_content = """Constituency,Incumbent Party,Conservative Vote Share (%) 2024,Conservative Votes (Gross) 2024,2024 Electorate,2024 Turnout,Conservative Vote Share Change,Candidate,Candidate Photo,,New MP?
Na h-Eileanan an Iar,Labour,5%,647,"21,325",63.4%,-17.4%,,,,YES
Orkney and Shetland,Liberal Democrats,3%,586,"34,236",60.4%,-7.1%,,,,NO
Liverpool Walton,Labour,3%,"1,282","69,317",53.2%,-6.4%,,,,NO
Knowsley,Labour,4%,"1,496","71,964",50.3%,-4.6%,,,,YES
Bootle,Labour,4%,"1,674","73,037",53.2%,-4.9%,,,,NO
Liverpool Riverside,Labour,4%,"1,155","71,380",45.4%,-4.2%,,,,NO
Liverpool West Derby,Labour,4%,"1,566","69,934",54.3%,-4.5%,,,,NO
Blaenau Gwent and Rhymney,Labour,13%,"3,776","70,153",42.7%,-7.0%,,,,NO
Manchester Rusholme,Labour,6%,"1,678","72,608",40.0%,-3.3%,,,,NO
Blackley and Middleton South,Labour,10%,"3,073","72,303",43.3%,-18.4%,,,,NO
Leeds South,Labour,13%,"4,172","75,953",41.7%,-13.1%,,,,NO
Widnes and Halewood,Labour,9%,"3,507","70,161",54.3%,-11.6%,,,,NO
Doncaster North,Labour,23%,"7,105","69,759",44.4%,-10.3%,,,,NO
Sheffield Central,Labour,7%,"2,339","60,594",52.5%,-5.0%,,,,YES
Sheffield Brightside and Hillsborough,Labour,13%,"4,069","70,389",44.9%,-12.5%,,,,NO
Leeds Central and Headingley,Labour,7%,"2,237","70,554",44.8%,-10.8%,,,,NO
Peckham,Labour,6%,"2,276","72,127",53.8%,-5.3%,,,,YES
Vauxhall and Camberwell Green,Labour,7%,"2,809","77,527",48.4%,-7.0%,,,,NO
Wolverhampton South East,Labour,17%,"5,654","77,473",43.1%,-24.3%,,,,NO
Hackney North and Stoke Newington,Labour,8%,"3,457","77,812",52.6%,-4.6%,,,,NO
Liverpool Wavertree,Labour,5%,"1,887","70,581",56.4%,-4.9%,,,,NO
Kingston upon Hull East,Labour,9%,"2,715","70,650",42.2%,-25.2%,,,,NO
Nottingham East,Labour,11%,"3,925","69,395",52.5%,-10.0%,,,,NO
Hackney South and Shoreditch,Labour,5%,"2,076","78,277",53.3%,-5.4%,,,,NO
Lewisham East,Labour,11%,"4,401","73,380",55.4%,-9.2%,,,,NO
Sheffield South East,Labour,17%,"6,252","74,156",48.2%,-18.1%,,,,NO
Tottenham,Labour,6%,"2,320","75,906",52.9%,-5.3%,,,,NO
Sheffield Heeley,Labour,14%,"5,242","73,452",52.3%,-13.5%,,,,NO
Rawmarsh and Conisbrough,Labour,13%,"4,496","69,133",49.0%,-23.7%,,,,NO
Nottingham South,Labour,16%,"5,285","64,255",51.2%,-15.5%,,,,NO
Liverpool Garston,Labour,7%,"2,943","69,282",60.6%,-4.7%,,,,NO
Croydon West,Labour,17%,"6,386","77,891",48.9%,-4.7%,,,,NO
Easington,Labour,11%,"3,753","69,395",49.5%,-16.2%,,,,NO
Ellesmere Port and Bromborough,Labour,12%,"5,210","70,799",59.3%,-14.7%,,,,NO
Airdrie and Shotts,Labour,5%,"1,696","70,199",52.2%,-12.7%,,,,YES
Jarrow and Gateshead East,Labour,9%,"3,354","70,272",52.3%,-14.6%,,,,NO
Hayes and Harlington,Labour,22%,"8,374","74,405",51.5%,-12.8%,,,,NO
Aberafan Maesteg,Labour,8%,"2,903","72,580",49.3%,-14.5%,,,,NO
Gorton and Denton,Labour,8%,"2,888","76,524",47.8%,-11.0%,,,,NO
Dulwich and West Norwood,Labour,9%,"3,873","79,894",56.8%,-8.1%,,,,NO
Wallasey,Labour,12%,"4,987","74,082",57.7%,-14.2%,,,,NO
Erith and Thamesmead,Labour,14%,"5,564","78,740",51.3%,-14.4%,,,,NO
Middlesbrough and Thornaby East,Labour,18%,"6,174","75,123",45.8%,-6.2%,,,,NO
Queen's Park and Maida Vale,Labour,13%,"5,088","75,558",50.7%,-6.5%,,,,YES
Smethwick,Labour,13%,"4,546","72,863",48.2%,-17.3%,,,,YES
Blackpool South,Labour,16%,"5,504","77,460",45.4%,-33.2%,,,,NO
Barnsley North,Labour,8%,"3,083","78,274",47.1%,-15.6%,,,,NO
East Ham,Labour,10%,"3,876","79,219",47.8%,-4.4%,,,,NO
Brent East,Labour,17%,"6,323","77,547",48.7%,-6.8%,,,,NO
Glasgow North East,Labour,3%,"1,182","72,610",47.0%,-7.5%,,,,YES
Westmorland and Lonsdale,Liberal Democrats,19%,"9,589","72,029",68.8%,-30.8%,,,,NO"""

def parse_csv_data():
    # Parse the CSV data
    reader = csv.reader(StringIO(csv_content))
    headers = next(reader)  # Skip header row
    
    data = []
    for row in reader:
        if len(row) >= 11:  # Ensure we have enough columns
            constituency_data = {
                "candidate": row[7] if len(row) > 7 else "",
                "candidatePhoto": row[8] if len(row) > 8 else "",
                "constituency": row[0],
                "incumbentParty": row[1],
                "conservativeVoteShare2024": row[2],
                "conservativeVotes2024": row[3],
                "electorate2024": row[4],
                "turnout2024": row[5],
                "conservativeVoteShareChange": row[6],
                "newMP": row[10] if len(row) > 10 else ""
            }
            data.append(constituency_data)
    
    return data

def generate_typescript_file(data):
    ts_content = f"""export interface ElectoralData {{
  candidate: string;
  candidatePhoto: string;
  constituency: string;
  incumbentParty: string;
  conservativeVoteShare2024: string;
  conservativeVotes2024: string;
  electorate2024: string;
  turnout2024: string;
  conservativeVoteShareChange: string;
  newMP: string;
}}

// Complete electoral data from the 2024 UK General Election - All {len(data)} constituencies
export const electoralData: ElectoralData[] = {json.dumps(data, indent=2)};
"""
    
    with open('../data/electoral-data.ts', 'w') as f:
        f.write(ts_content)
    
    print(f"Generated electoral-data.ts with {len(data)} constituencies")

if __name__ == "__main__":
    data = parse_csv_data()
    generate_typescript_file(data)
