import csv
import json

def process_complete_csv():
    data = []
    
    with open('/tmp/complete_electoral_data.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)  # Skip header row
        
        for row in reader:
            if len(row) >= 11:  # Ensure we have enough columns
                constituency_data = {
                    'candidate': row[7] if len(row) > 7 and row[7] else '',
                    'candidatePhoto': row[8] if len(row) > 8 and row[8] else '',
                    'constituency': row[0],
                    'incumbentParty': row[1],
                    'conservativeVoteShare2024': row[2],
                    'conservativeVotes2024': row[3],
                    'electorate2024': row[4],
                    'turnout2024': row[5],
                    'conservativeVoteShareChange': row[6],
                    'newMP': row[10] if len(row) > 10 and row[10] else ''
                }
                data.append(constituency_data)
    
    # Generate TypeScript file content
    ts_content = f'''export interface ElectoralData {{
  candidate: string;
  candidatePhoto: string;
  constituency: string;
  incumbentParty: string;
  conservativeVoteShare2024: string;
  conservativeVotes2024: string;
  electorate2024: string;
  turnout2024: string;
  conservativeVoteShareChange: string;
  newMP: string;
}}

// Complete electoral data from the 2024 UK General Election - All {len(data)} constituencies
export const electoralData: ElectoralData[] = {json.dumps(data, indent=2)};
'''
    
    # Write to TypeScript file
    with open('data/electoral-data.ts', 'w', encoding='utf-8') as f:
        f.write(ts_content)
    
    print(f'✅ Generated electoral-data.ts with {len(data)} constituencies')
    print(f'📊 Data includes all UK constituencies from the 2024 General Election')
    print('\n🔍 Sample constituencies:')
    for i, item in enumerate(data[:10]):
        print(f'  {i+1:2d}. {item["constituency"]} - {item["incumbentParty"]} ({item["conservativeVoteShare2024"]} Conservative)')
    
    print(f'\n📈 Vote share range:')
    # Find min and max vote shares (excluding N/A values)
    vote_shares = []
    for item in data:
        if item["conservativeVoteShare2024"] not in ['N/A', '']:
            try:
                vote_shares.append(int(item["conservativeVoteShare2024"].replace('%', '')))
            except:
                pass
    
    if vote_shares:
        print(f'  Lowest: {min(vote_shares)}% | Highest: {max(vote_shares)}%')
    
    return len(data)

if __name__ == '__main__':
    count = process_complete_csv()
    print(f'\n🎉 Successfully processed {count} constituencies!')
